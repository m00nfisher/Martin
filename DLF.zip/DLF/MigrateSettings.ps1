﻿#
# Use this PowerShell script to export the server configuration from a downlevel version of Azure AD Connect 
# that does not support the new JSON settings import and export feature.
#
#  Migration Steps
#
#     Please read the complete instructions for performing an in-place versus a legacy settings migration before
#     attempting the following steps: https://go.microsoft.com/fwlink/?LinkID=2117122
#
#     1.) Copy this script to your production server and save the downlevel server configuration directory
#         to a file share for use in installing a new staging server.
#
#     2.) Run this script on your new staging server and pass in the location of the configuration directory
#         generated in the previous step.  This will create a JSON settings file which can then be imported
#         in the Azure Active Directory Connect tool during Custom installation.
#

Param (
    [Parameter (Mandatory=$false)]
    [string] $ServerConfiguration
)
$helpLink = "https://go.microsoft.com/fwlink/?LinkID=2117122"
$helpMsg = "Please see $helpLink for more information."
$adSyncService = "HKLM:\SYSTEM\CurrentControlSet\services\ADSync"

# An installed wizard is the baseline requirement for this script
$wizard = Get-ItemProperty -Path "HKLM:\Software\Microsoft\Azure AD Connect" -ErrorAction Ignore
if ($wizard.WizardPath)
{
    [version] $wizardVersion = [Diagnostics.FileVersionInfo]::GetVersionInfo($wizard.WizardPath).FileVersion
    try {
        # The ADSync service must be installed in order to extract settings from the production server
        $service = Get-ItemProperty -Path $adSyncService -Name ObjectName -ErrorAction Ignore
        if (!$service.ObjectName)
        {
            Write-Host
            Write-Host "Azure AD Connect must be installed and configured on this server for settings migration to succeed."
            Write-Host "The Microsoft Azure AD Connect synchronization service (ADSync) is not present."
            Write-Host $helpMsg
            exit
        }

        $programData = [IO.Path]::Combine($Env:ProgramData, "AADConnect")
        if (!$ServerConfiguration)
        {
            # Create a temporary directory under %ProgramData%\AADConnect
            $tempDirectory = ("Exported-ServerConfiguration-" + [System.Guid]::NewGuid())
            $ServerConfiguration = [IO.Path]::Combine($programData, $tempDirectory)
        }

        # Export the server configuration in a new PS session to avoid loading legacy cmdLet assemblies
        try
        {
            # try first with new parameter that will validate the configuration 
            Get-ADSyncServerConfiguration -Path $ServerConfiguration $true
        }
        catch [System.Management.Automation.ParameterBindingException]
        {
            Get-ADSyncServerConfiguration -Path $ServerConfiguration
        }

        # Copy over the PersistedState.xml file to the configuration directory
        Copy-Item -Path "$programData\\PersistedState.xml" -Destination $ServerConfiguration

        $author = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        $timeCreated = $(Get-Date).ToUniversalTime().ToString("u", [System.Globalization.CultureInfo]::InvariantCulture)
        $policyMetadata = [ordered]@{
            "type" = "migration"
            "author" = $author
            "timeCreated" = $timeCreated
            "azureADConnectVersion" =  $wizardVersion.ToString()
        }

        $hostName = ([System.Net.Dns]::GetHostByName(($env:computerName))).Hostname
        $serviceParams = Get-ItemProperty -Path "$adSyncService\Parameters" -ErrorAction Ignore
        $databaseServer = $serviceParams.Server
        $databaseInstance = $serviceParams.SQLInstance
        $databaseName = $serviceParams.DBName

        # Retrieve the service account type for documentation purposes (may not be present on old builds)
        $serviceAccountType = "Unknown"
        $msolCoexistence = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\MSOLCoExistence" -ErrorAction Ignore
        if ($msolCoexistence.ServiceAccountType)
        {
            $serviceAccountType = $adSync.ServiceAccountType
        }
        
        [string[]]$connectorIds =(Get-ADSyncConnector | Select-Object -Property Identifier).Identifier

        # NOTE: databaseType is a calculated field and is intentionally ommitted
        $deploymentMetadata = [ordered]@{
            "hostName" = $hostName
            "serviceAccount" = $service.ObjectName
            "serviceAccountType" = $serviceAccountType
            "databaseServer" = $databaseServer
            "databaseInstance" = $databaseInstance
            "databaseName" = $databaseName
            "connectorIds" = $connectorIds
        }

        $policyJSON = [ordered]@{
            "policyMetadata" = $policyMetadata
            "deploymentMetadata" = $deploymentMetadata
        }                 

        # Create MigratedPolicy.json for the production server
        $policyJSON | ConvertTo-Json | Out-File "$ServerConfiguration\MigratedPolicy.json"

        Write-Host
        Write-Host "The downlevel server configuration was successfully exported.  Copy the entire directory to"
        Write-Host "your new staging server and select 'MigratedPolicy.json' from the UI to import these settings."
        Write-Host
        Write-Host "   " $ServerConfiguration
        Write-Host
        Write-Host "Please see $helpLink for more information on completing this process."
    }
    catch {
        Write-Host "Unable to export the server configuration due to an unexpected error."
        Write-Host $helpMsg
        Write-Host "Message: $($_.Exception.Message)" -ForegroundColor Yellow
    }
    exit
}
else
{
    Write-Host
    Write-Host "The Azure AD Connect tool must be installed on this server for settings migration to succeed."
    Write-Host $helpMsg
}
# SIG # Begin signature block
# MIInogYJKoZIhvcNAQcCoIInkzCCJ48CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBFmuzW644A2hIU
# e0doTQIQOOZ59uIfCm+FbtM2rs/A1qCCDYIwggYAMIID6KADAgECAhMzAAACXYZY
# Xl3YQG2FAAAAAAJdMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjEwOTAyMTgzMzA5WhcNMjIwOTAxMTgzMzA5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDmfHyBIDizmcgcjwA2xbClOyPRmfoeR/n5X+vgf6KBvTNTpxJ7mAvmERR6Cqju
# 9wmXzC2yfR46iXVp9ANAis5oeHHmGonpBQ6S6ekyXISO7gS1/5bE2t6gOtYehOe9
# vCuZRjjado1J6yo4iq46Bj+FzIhmXUCp77jN7i64hzJX6lNRo63Ywg39ilIbTf8p
# apY3coisH7KliEsaA+btecOtVXD09acdqy+U1y/Zntqxcbd7MXtDetPIjE2GqrxS
# MySfmCjTUCU3s3taE2dLDcigKHG+V+3KxgwSJgUIADhnochGfiqk3eHAw2nxD/QK
# +Zbt1XP+vxXFOWE7xqCdpQMrAgMBAAGjggF/MIIBezArBgNVHSUEJDAiBgorBgEE
# AYI3TBMBBgorBgEEAYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU41PqNtHEB/zv
# DQGQd+ryF6aH3/cwRQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEWMBQGA1UEBRMNMjMzMTEwKzQ2NzQ5NzAfBgNVHSMEGDAWgBRI
# bmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEt
# MDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAH8V
# iPsIw0osUqRoBZY6JqDq4JT3gEMOrCvcCigX+HiKtZ5QPnXN9iuW3Djv8FtMiLLw
# jbRVGGmLqQQRTUtVPAXCU+RY0DupBsH2qp9lvDylH55XT0TlTfjxx9GXv4QN/PI4
# M5IMLPczdAtvO/5+sLfMKk24YS00Pu5jDYS676+BLs7fYqu54AiVv4TryQG6etrS
# M3AMzs9oF6hY3GmofisEnNduvJL4Dd0i2T54lKkt9cMxURLxwemS3jj9TGrMeXTh
# Z89Pi0HtEqwqRLJzFfwnrpUwjfIFlqmhuX5eQC3QNeHzFQe73QXETrunLdeJud+G
# 3aZmaaEusSsc3lWkdf1codA5FOWM4SfRSfFT1frJNtoMDxyzp/pur5JXeaELzTMM
# 3wCVCA8XE5kE2INrBjcbJDOXzWcUXrw347Y3qYMZGT9vK9DfrR24G0MQBHT9M5lo
# 8sX/rg+JQCx+Gr1yTd04fH0trbIu6HfsWTfo0zcCw1goMQO5D9YE4pRpO+aLS7Je
# OprHwQHKNzio1Dicglofb91XouQNvLxNVf4GbkRy7zCqNbg3v5CQJOQGFQ6N6G7o
# 9FBn/JXDKXmmlXYu3Da3OKapXGjoPAfuSkWwGnBQy0PkN/SVxABEAEs9hzMcZ8/a
# GTFH/OJO0OR6uqq3hwB1zexKGoV3BjErgNVN0shfMIIHejCCBWKgAwIBAgIKYQ6Q
# 0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5
# WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQD
# Ex9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4
# BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe
# 0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato
# 88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v
# ++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDst
# rjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN
# 91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4ji
# JV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmh
# D+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbi
# wZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8Hh
# hUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaI
# jAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTl
# UAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNV
# HQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQF
# TuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29m
# dC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNf
# MjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5t
# aWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNf
# MjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcC
# ARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnlj
# cHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5
# AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oal
# mOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0ep
# o/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1
# HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtY
# SWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInW
# H8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZ
# iWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMd
# YzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7f
# QccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKf
# enoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOpp
# O6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZO
# SEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGXYwghlyAgEBMIGVMH4xCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jv
# c29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAJdhlheXdhAbYUAAAAAAl0w
# DQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIC27rh7y
# 5VXdMTFAmR/PdYFbszAGaWCn5XNWWwWOerkeMEIGCisGAQQBgjcCAQwxNDAyoBSA
# EgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20w
# DQYJKoZIhvcNAQEBBQAEggEA1e2bKUlUuNDJCt+EgzUciBgIP3QMYOJgKTZQx9yp
# QVq/UBNF9UoOo+nQAF7mNGLWt7wmMI6WgYOXqjVOjhWciNscT4iFaPEsR0VF06tF
# g/+AnQ3+c9PoyN2jeISQOcRdeanWlc/cPWhlDxKmyzwDbcGESrRCeeXXWq8nkwgr
# xYl/OqaOrZLksI2RCZvSvI87TlAmdFzEJ/tRO+6jrLkoQ245t+9+50k6A2wRJoeW
# 2CyGaTW9hllCiRYoCJdyLtcAYBdXeqLbRwNvFjNahCXHBYLkZVgRRE4bYNp9/YJT
# oArOk97rYn7sX59hzWtseiemOImIofRiDq9WX6XNo9ICu6GCFwAwghb8BgorBgEE
# AYI3AwMBMYIW7DCCFugGCSqGSIb3DQEHAqCCFtkwghbVAgEDMQ8wDQYJYIZIAWUD
# BAIBBQAwggFRBgsqhkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoD
# ATAxMA0GCWCGSAFlAwQCAQUABCArmJIKaNl85HuV3PZUR/LEP2GgtOA+w8FkRqPY
# 22DtdwIGYhZfokAPGBMyMDIyMDMyMzAwMDI1MC4wNjJaMASAAgH0oIHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjpFNUE2LUUyN0MtNTkyRTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaCCEVcwggcMMIIE9KADAgECAhMzAAABlbf8DdbjNzElAAEAAAGV
# MA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4X
# DTIxMTIwMjE5MDUxMloXDTIzMDIyODE5MDUxMlowgcoxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNh
# IE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkU1QTYtRTI3Qy01
# OTJFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjAN
# BgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAn21BDGe2Szs/WqEQniS+IYU/UPCW
# QdsWlZTDQrd28IXEyORiz67dnvdwwLJpajs8NXBYjz4OkubCwl8+y221EKS4WvEu
# L9qnHDLU6JBGg0EvkCRK5wLJelUpkbwMtJ5Y/gvz2mbi29zs2NAEcO1HgmS6cljz
# x/pOTHWI+jVA0zaF6m80Bwrj7Pn4CKK6Octwx6DtO+4OiK9kxyMdcn1RRLecw3BT
# zmDIOMgYuAOl3N4ZvbWesPOPZwb1SsJuWAC3x98v395+C5zetW9cMwMd2QmY39d1
# Cm6RO6eg2Cax0Qf/qcBYxvfU8Bx+rl8w3mU+v6+qh+wAAcJ/H6WHNU5pXhWPGEbl
# c846fVZDx1fFc78yy+0CtpLXnlyy/2OJb4y+oc8jphPtS1Q95RG2IaNcwrfhe21P
# haY8gX0wuIv8B7KbW9tfGJW5ELdYtQepZZicFRcAi1+4MUOPECBlGnDMvJKdfs3M
# 2PksZaWhIDZkJH3Na2j4fcubDGul+PPsdCuwfDqg6F3E4hAiIyXrccLbgZULHidO
# R0X4rH4BZtPZBu73RxKNzW1LjDARYpHOG6DfVH5tIlIavybaldCsK7/Qr92sg4HT
# cBFoi9muuSJxFkqUU2H7AkNN3qhIeQN68Ffyn1BXIrfg6z/vVXA6Y1kbAqJGb+LY
# J+agFzTLR2vDYqkCAwEAAaOCATYwggEyMB0GA1UdDgQWBBSrl9NiAhRXV4K3AgZg
# yXx+b/ypFzAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8E
# WDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9N
# aWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYB
# BQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEw
# KDEpLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqG
# SIb3DQEBCwUAA4ICAQDgszbeHyfozr0LqtCLZ9+yGa2DQRrMAIviABTN2Biv8BkJ
# RJ3II5jQbmnPeVtnwC+sbRVXzH5HqkizC6qInVbFPQZuAxAY2ljTk/bl/7XGIiUn
# xUDNKw265fFeJzPPEWReehv6iVvYOXSKjkqIpsylLf0O1h+lQcltLGq+cBr4KLyt
# 6hWncCkoc0WHBKk5Bx9s4qeXu943szx8dvrWmKiRucSc3QxK2dZzIsUY2h7NyqXL
# JmWLsbCEXwWDibwBRspkxkb+T7sLDabPRHIdQGrKvOB/2P/MTdxkI+D9zIg5/Is1
# AQwrlyHx2JN/W6p2gJhW1Igm8vllqbs3ZOKAys/7FsK57KEO9rhBlRDe/pMsPfh0
# qOYvJfGYNWJo/bVIA6VVBowHbqC8h0O16pJypkvZCUgSpOKJBA4NCHei3ii0MB9X
# uGlXk8lGMHAV98IO6SyUFr0e52tkhq7Zf9t2BkE7nZljq8ocfZZ1OygRlf2jb89L
# U6XLLnLCvnGRSgxJFgf6FBVa7crp+jQ+aWGTY9AoEbqeYK1QAqvwIG/hDhiwg/sx
# LRjaKeLXyr7GG+uNuezSfV6zB4KQom++lk9+ET5ggQcsS1JB8R6ucwsmDbtCBVwL
# dQFYnMNeDPnMy2CFTOzTslaRXXAdQfTIiYpO6XkootF00XZef1fyrHE2ggRc9zCC
# B3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAw
# gYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMT
# KU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIx
# MDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57Ry
# IQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VT
# cVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhx
# XFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQ
# HJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1
# KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s
# 4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUg
# fX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3
# Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je
# 1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUY
# hEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUY
# P3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGC
# NxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4w
# HQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYB
# BAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcD
# CDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0T
# AQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNV
# HR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9w
# cm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEE
# TjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2Nl
# cnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOC
# AgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/a
# ZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp
# 4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq
# 95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qB
# woEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG
# +jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3B
# FARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77
# IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJ
# fn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K
# 6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDx
# yKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLOMIICNwIBATCB
# +KGB0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEl
# MCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMd
# VGhhbGVzIFRTUyBFU046RTVBNi1FMjdDLTU5MkUxJTAjBgNVBAMTHE1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVANGPgsi3sxoFR1hT
# ZiiNS7hP4WOroIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAw
# DQYJKoZIhvcNAQEFBQACBQDl5HW6MCIYDzIwMjIwMzIzMDAyMDEwWhgPMjAyMjAz
# MjQwMDIwMTBaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOXkdboCAQAwCgIBAAIC
# I1ACAf8wBwIBAAICEcgwCgIFAOXlxzoCAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYK
# KwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUF
# AAOBgQAUd/uXcqBpQjVmZWCVsZyCuNnm0KIdwlPZhL1TgWvOeaMyX3zjjfR0qv5y
# zR4xj+mqXjzXuwbEAT3arB3rZR2kmgcaK5E+N5BJGtMk+uBIJW0K7p14uKrDxO+F
# F/p6SS11VmFc/JW7/f2Q/95x8KOLiG0huiKJnVDTiwOC02DnIjGCBA0wggQJAgEB
# MIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABlbf8DdbjNzEl
# AAEAAAGVMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcN
# AQkQAQQwLwYJKoZIhvcNAQkEMSIEIEaBwHkBUHWQkdPdtyZiAjF8RKAm82nNvR3r
# 9szB3MvUMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgXOZL4Y2QC3tpoSM/
# 0He5HlTpgP3AtXcymU+MmyxJAscwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFt
# cCBQQ0EgMjAxMAITMwAAAZW3/A3W4zcxJQABAAABlTAiBCCscOVN0EwkTqROT6e8
# ohLX3NJFPz0VhTEbMd1xNuK47zANBgkqhkiG9w0BAQsFAASCAgCRzdTmjyMbbqJ/
# fAbbGxGG87gbxBNtI0oysjsvL5MkNNhWkxol/9royDsdvFy21oaDwxenPxL534VG
# h4p2EU3hQE1UtllmbFZoQBpE6lJg+eg32DQmdsMN1hWaR+d87TbEznI2Np58YSxk
# 5pylyIpVV5arnSm3NZyYS9dnTR6vh55ZPhsS9s8Cvax15SWGwRu6kelyfabRd/fl
# jM/VuJsT4/ABxRQJux7vrHZWelJMRxCdxz6u3W2P8DFqDrxmQkwafFtSEu4nuv+z
# /+lnaf/c9NRvIhfYyd2M29TLkBn0762VQhfsH1wGq2wX32nxZ3GuNDPThRHkH09I
# /4l0oF53oIYgblsDx5VDkkINN9DS+N583MYX8k24KJcL5530gWXQyz5fvJ+Z+OA0
# bvpRjKfIx5pYnfeRdl7uaQmUbd2SqSPEPoPRrg07+sbXA8DvyPEi57BIOpZUcO4a
# dfTiK4Y4jo4dgh/1XI99GF79+S8FdH2fvKX30cxBZFEUHY7BM1IepjSGLdzjpcQE
# SXvlOU97ghlVhx45ZNjiIPTDtSgXoGNjuK+MkbhjS5vS51rFOYHULffgUSUa5fDM
# Qz5sbMY7gu4i47+jgV66SpboRE3TwaiCpRDOjZgfm3bmGgu92p/hnkzScN/Jpa+J
# JqO2Tbc4WLspkn27ODUtg+Q3RlbxWg==
# SIG # End signature block
